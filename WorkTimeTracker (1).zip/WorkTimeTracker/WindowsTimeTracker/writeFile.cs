﻿using System;
using System.IO;
using System.IO.Compression;

namespace WindowsFormsApplication1
{
    class writeFile
    {


        public static void CreateDireatory(string PATH)
        {
           
            Directory.CreateDirectory(PATH);
           
            try
            {
             
                if (Directory.Exists(PATH))
                {
                    Console.WriteLine("That PATH exists already.");
                    return;
                }

                
                DirectoryInfo di = Directory.CreateDirectory(PATH);
                Console.WriteLine("The directory was created successfully at {0}.", Directory.GetCreationTime(PATH));

                di.Delete();
                Console.WriteLine("The directory was deleted successfully.");
            }
            catch (Exception e)
            {
                Console.WriteLine("The process failed: {0}", e.ToString());
            }
            finally { }
        }


        public static void WriteFile(string PATH, string createText)
        {

            string path = "\\start\\start" + DateTime.Now.DayOfYear + ".txt";
            if (File.Exists(path)){
                File.WriteAllText(PATH + path, createText);
            }
            
        }
        public static void zipFile(string PATH)
        {
            int n = 0;
            var zipFile = PATH + "\\result" + DateTime.Now.DayOfYear +"_" +  n +".zip";
            while (File.Exists(zipFile))
            {
                n++;
                zipFile = PATH + "\\result" + DateTime.Now.DayOfYear + "_" + n + ".zip";

            }
            var files = Directory.GetFiles(PATH);
            using (var archive = ZipFile.Open(zipFile, ZipArchiveMode.Create))
            {
                foreach (var fPath in files)
                {
                    archive.CreateEntryFromFile(fPath, Path.GetFileName(fPath));
                }
            }
            var deletefiles = Directory.GetFiles(PATH);
            foreach (string filePath in files)
            {
                var name = new FileInfo(filePath).Name;
                name = name.ToLower();
                if (name != "result.zip")
                {
                    File.Delete(filePath);
                }
            }
        }
        
    }
}
