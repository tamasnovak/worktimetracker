﻿using System;
using System.Runtime.InteropServices;

namespace WindowsFormsApplication1
{

    internal struct LASTINPUTINFO
        {
            public uint cbSize;

            public uint dwTime;
        }

        public class LastInput

        {
        [DllImport("User32.dll")]
            private static extern bool GetLastInputInfo(ref LASTINPUTINFO plii);

            [DllImport("Kernel32.dll")]
            private static extern uint GetLastError();

          
        public static long IdleTime() 
        {
            LASTINPUTINFO lastinputinfo = new LASTINPUTINFO();
            lastinputinfo.cbSize = (uint) Marshal.SizeOf(lastinputinfo);
            GetLastInputInfo(ref lastinputinfo);
            return (((Environment.TickCount & int.MaxValue) - (lastinputinfo.dwTime & int.MaxValue)) & int.MaxValue) / 1000;
        }
    }
}
