﻿using System;
using System.Windows.Forms;
using System.Drawing.Imaging;
using System.IO.Compression;
using System.IO;
using System.Linq;

namespace WindowsFormsApplication1
{
    public partial class worktime : Form
    {
        const int IDLETIME = 299;
        const int RANDOMNUMBER = 3600;
        string PATH = @"c:\Worktime\start" + DateTime.Now.DayOfYear;

        string createText = "Hello and Welcome" + Environment.NewLine;
        string evenAppWind, oddAppWind = " ";
        int sec, min, hours;

        int pictureNumber;
        int secTemp;
        int randomNumber;

        Random rnd = new Random();
        active_window active = new active_window();





        public worktime()

        {
            writeFile.CreateDireatory(PATH);
            writeFile.WriteFile(PATH, createText);
            InitializeComponent();
            sec = min = hours = 0;
            pictureNumber = 0;


        }

        private void button1_Click(object sender, EventArgs e)
        {

            timer1.Start();
            timer2.Start();

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            sec++;
            if (sec % RANDOMNUMBER == 0)
            {
                secTemp = sec;
                randomNumber = rnd.Next(RANDOMNUMBER);
            }
            if (sec % 2 == 0)
            {

                evenAppWind = active.GetActiveWindowTitle();
                if (!String.IsNullOrEmpty(evenAppWind) && !String.IsNullOrEmpty(oddAppWind) && !evenAppWind.Equals(oddAppWind))
                {
                    string path = "\\start" + DateTime.Now.DayOfYear + ".txt";
                    string dateTime = DateTime.Now.Hour + " : " + DateTime.Now.Minute + " : " + DateTime.Now.Second + "  ";
                    string createText = dateTime + active.GetActiveWindowTitle() + Environment.NewLine;
                    File.AppendAllText(PATH + path, createText);
                }
            }
            else
            {
                oddAppWind = active.GetActiveWindowTitle();
            }



            if (secTemp + randomNumber == sec)
            {
                var image = ScreenCapture.CaptureDesktop();
                image.Save(PATH + "\\dayofyear" + DateTime.Now.DayOfYear + "screenpic" + pictureNumber + ".jpg", ImageFormat.Jpeg);
                pictureNumber++;
            }

            if (sec >= 60)
            {
                min++;
                sec = 0;
            }
            if (min >= 60)
            {
                hours++;
                min = 0;
            }
            if (hours > 11)
            {
                timer1.Stop();
                label4.Text = "You reached the maximum time that you could a day! Please take a rest! ";

            }
            label1.Text = sec.ToString();
            label2.Text = min.ToString();
            label3.Text = hours.ToString();
            if (IDLETIME < LastInput.IdleTime())
            {
                timer1.Stop();
                DialogResult answer = MessageBox.Show((new Form { TopMost = true }), "You're worktime tracker is paused. Would you like to continue?", "Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (answer == DialogResult.Yes)
                { 
                    timer1.Start();

                }
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            DateTime dateTimeNow = DateTime.Now;
            label5.Text = dateTimeNow.ToString();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            timer1.Stop();
            var image = ScreenCapture.CaptureDesktop();
            image.Save(PATH + "\\workingtime.jpg", ImageFormat.Jpeg);
            DialogResult answer = MessageBox.Show((new Form { TopMost = true }), "Are you finished for today?", "Confirm",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (answer == DialogResult.Yes)
            {

                pictureNumber++;
                writeFile.zipFile(PATH);
            }
            else
            {
                timer1.Start();
            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }


        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            timer3.Stop();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}


